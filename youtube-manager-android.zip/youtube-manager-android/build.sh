#!/bin/bash
# Quick build script
npm install
node build-android.js
